# This is the awesome Classic Thesis @ DEIB template 

[Download the instructions first!](https://github.com/Lordmzn/ClassicThesis-at-DEIB/raw/master/ClassicThesis_DEIB.pdf)

![Classic Thesis @ DEIB logo](TEXT_template/Images/logoTemplate.png) This template is what you are looking for if you want to write an awesome thesis at Dipartimento di Elettronica, Informazione e Bioingegneria at [Politecnico di Milano](http://www.polimi.it). It is a modified version of Classic Thesis by André Miede that can be found [here](http://code.google.com/p/classicthesis/). Open the `ClassicThesis_DEIB.pdf` to find specific informations on the usage.

TEXT_template
PRESENTATION_template

## Authors
- [Daniela Anghileri](daniela.anghileri@polimi.it)
- [Andrea Cominola](andrea.cominola@polimi.it)
- [Emanuele Mason](emanuele.mason@polimi.it)
